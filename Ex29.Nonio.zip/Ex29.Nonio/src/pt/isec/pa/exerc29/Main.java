package pt.isec.pa.exerc29;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        System.out.println("Base Exerc 29");
        Application.launch(MainJFX.class,args);
    }
}