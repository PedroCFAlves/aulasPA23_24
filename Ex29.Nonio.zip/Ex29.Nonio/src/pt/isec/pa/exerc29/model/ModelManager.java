package pt.isec.pa.exerc29.model;

public class ModelManager {
    Figure figure;

    public ModelManager() {
        figure = new Figure();
    }

    /* TODO */
}
