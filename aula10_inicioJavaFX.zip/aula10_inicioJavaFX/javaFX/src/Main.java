import javafx.application.Application;

import pt.isec.aula_javafx1.ui.gui.MainJFX;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainJFX.class, args);
    }
}