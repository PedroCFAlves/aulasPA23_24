package pt.isec.aula_javafx1.data;

import com.sun.javafx.fxml.builder.JavaFXImageBuilder;
import com.sun.javafx.fxml.builder.JavaFXSceneBuilder;
import javafx.scene.paint.Color;

public class ModelData {

}
