package pt.isec.aula_javafx1;

public class teste {
}
